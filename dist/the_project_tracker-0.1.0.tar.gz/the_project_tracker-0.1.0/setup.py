# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['the_project_tracker',
 'the_project_tracker.cli',
 'the_project_tracker.core',
 'the_project_tracker.db']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy==1.4.41',
 'click>=8.0,<9.0',
 'ipykernel>=6.21.3,<7.0.0',
 'markdownlit',
 'pandas>=1.5.3,<2.0.0',
 'psycopg2-binary>=2.9.6,<3.0.0',
 'pydantic>=1.10.6,<2.0.0',
 'pytest>=7.2.2,<8.0.0',
 'python-dotenv>=1.0.0,<2.0.0',
 'requests>=2.28.2,<3.0.0',
 'selenium>=4.8.2,<5.0.0',
 'sqlmodel>=0.0.8,<0.0.9',
 'streamlit>=1.21.0,<1.22.0',
 'streamlit_pills==0.3.0']

entry_points = \
{'console_scripts': ['the_project_tracker = '
                     'the_project_tracker.cli:pipeline_cli']}

setup_kwargs = {
    'name': 'the-project-tracker',
    'version': '0.1.0',
    'description': 'Code projects AI tracker',
    'long_description': '\n## TODO LIST:\n\n- [X] Add local SQLite database connector\n- [X] Add tables and data models\n- [X] Create Retriever and Explainer\n- [X] Create PRs pipeline\n- [X] Create Releases pipeline\n- [X] Create client\n- [X] Add managed Postgres database connector\n- [X] Create Streamlit app\n- [X] User new project implementation\n- [X] Pre-commit, mypy...\n- [] Añadir apartado de últimas releases, en general\n- [] README\n- [] Añadir PR info. Filtro out PR info\n- [] Video explicativo\n- [] Major updates filter\n- [] Env vars in config YAMLs\n- [] Nested Links (#Whatsnew pages, etc) Handler\n- [] Modo Local / Configuración\n- [] Configure Logs\n',
    'author': 'Carlos Vecina',
    'author_email': 'carlos.vecina@jobandtalent.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
