
## TODO LIST:

- [X] Add local SQLite database connector
- [X] Add tables and data models
- [X] Create Retriever and Explainer
- [X] Create PRs pipeline
- [X] Create Releases pipeline
- [X] Create client
- [X] Add managed Postgres database connector
- [X] Create Streamlit app
- [X] User new project implementation
- [X] Pre-commit, mypy...
- [] Añadir apartado de últimas releases, en general
- [] README
- [] Añadir PR info. Filtro out PR info
- [] Video explicativo
- [] Major updates filter
- [] Env vars in config YAMLs
- [] Nested Links (#Whatsnew pages, etc) Handler
- [] Modo Local / Configuración
- [] Configure Logs
